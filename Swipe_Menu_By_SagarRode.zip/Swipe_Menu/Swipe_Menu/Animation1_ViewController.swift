//
//  Animation1_ViewController.swift
//  SR iOS Best Demos
//
//  Created by Sagar on 22/09/17.
//  Copyright © 2017 Beyond. All rights reserved.
//

import UIKit

class Animation1_ViewController: UIViewController {

    @IBOutlet weak var label_Name: UILabel!
    @IBOutlet weak var label_Motto: UILabel!
    
    @IBOutlet weak var buttonX_Up: UIButton!
    @IBOutlet weak var imageView_Background: UIImageView!
    @IBOutlet weak var view_StackViewContainer: UIView!
    
    @IBOutlet weak var View_Animation: UIView!
    @IBOutlet weak var constraint_AnimationView_Height: NSLayoutConstraint!
    
    var gesture_SwipeUp = UISwipeGestureRecognizer()
    var gesture_SwipeDown = UISwipeGestureRecognizer()

    override func viewDidLoad() {
        super.viewDidLoad()

        imageView_Background.alpha = 0
        View_Animation.alpha = 0
        label_Name.alpha = 0
        label_Motto.alpha = 0
        
        gesture_SwipeUp.direction = .up
        gesture_SwipeDown.direction = .down
        gesture_SwipeUp.addTarget(self, action: #selector(swipeUpView))
        gesture_SwipeDown.addTarget(self, action: #selector(swipeDownView))
        
        View_Animation.addGestureRecognizer(gesture_SwipeUp)
        View_Animation.addGestureRecognizer(gesture_SwipeDown)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        constraint_AnimationView_Height.constant = 50
        
        UIView.animate(withDuration: 1, animations: {
            self.imageView_Background.alpha = 0.9
        }) { (true) in
            self.show_TitleLabelAnimation()
        }
    }
    
    func show_TitleLabelAnimation() {
        UIView.animate(withDuration: 1, animations: {
            self.label_Name.alpha = 1
        }) { (true) in
            self.show_MottoLabelAnimation()
        }
    }
    
    func show_MottoLabelAnimation() {
        UIView.animate(withDuration: 1, animations: {
            self.label_Motto.alpha = 1
        }) { (true) in
            self.show_AnimationViewAnimation()
        }
    }
    
    func show_AnimationViewAnimation() {
        UIView.animate(withDuration: 1, animations: {
            self.View_Animation.alpha = 1
        })
    }
    
    func swipeUpView() {
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 1, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            self.constraint_AnimationView_Height.constant = CGFloat(100)
            self.buttonX_Up.isSelected = true
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    func swipeDownView() {
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 1, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            self.constraint_AnimationView_Height.constant = CGFloat(50)
            self.buttonX_Up.isSelected = false
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    @IBAction func button_UpAnimationView_Tapped(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        let height = sender.isSelected ? 100 : 50
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 2, initialSpringVelocity: 0.5, options: .curveEaseIn, animations: {
            self.constraint_AnimationView_Height.constant = CGFloat(height)
            self.view.layoutIfNeeded()
        }, completion: nil)
        
    }
    
}
